---
name: reviewing-resumes
description: Performs visual QA on resume PDFs using structured checklists. Use when the user asks to review a PDF, check layout issues, evaluate formatting, or wants feedback before submitting.
license: MIT
compatibility: opencode
metadata:
  audience: job-seekers
  workflow: resume-management
---

# Resume Reviewer

Visual QA on resume PDFs using structured checklists.

## Workflow

1. **View the PDF** — Read the compiled PDF file
2. **Run the checklist** — Evaluate against visual_qa_checklist.md
3. **Identify issues** — Cross-reference with common_issues.md
4. **Provide feedback** — Use structured format

## Quick Evaluation

Check these critical items first:

1. **Page overflow** — Does content fit on expected pages (1-2)?
2. **Readability** — Is text large enough, spacing adequate?
3. **Visual balance** — Is whitespace well-distributed?
4. **Hierarchy** — Is the name most prominent, sections clear?
5. **Alignment** — Are dates, bullets, sections aligned?

## Feedback Format

```
## Visual QA Results

### Pass/Fail Summary
- Layout: [PASS/FAIL]
- Typography: [PASS/FAIL]
- Whitespace: [PASS/FAIL]
- Alignment: [PASS/FAIL]

### Issues Found
1. [Specific issue with location]

### Recommended Adjustments
1. [Specific adjustment to fix]
```

## Integration

Works with `creating-resume-templates` in iteration loop:
- Template maker adjusts → compile → reviewer evaluates → repeat until PASS
