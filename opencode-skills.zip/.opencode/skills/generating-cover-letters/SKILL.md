---
name: generating-cover-letters
description: Generates professional cover letters matching resume templates. Use when the user needs a cover letter, is applying for a job, or wants matching application materials with consistent styling.
license: MIT
compatibility: opencode
metadata:
  audience: job-seekers
  workflow: resume-management
---

# Cover Letter Generator

Generate professional cover letters matching resume design.

## Quick Start

```bash
# Generate cover letter
python resume-coverletter/scripts/generate_cover_letter.py resume.yaml \
  --template tech-modern-cover \
  --company "Company" \
  --position "Job Title" \
  --job-file job_description.txt \
  --output cover_letter.typ

# Compile to PDF
python resume-coverletter/scripts/compile_cover_letter.py cover_letter.typ --output cover_letter.pdf
```

## Available Templates

| Template | Matches |
|----------|---------|
| tech-modern-cover | tech-modern resume |
| executive-cover | executive resume |
| generic-cover | Any template |

## Content Structure

### Opening
- Express interest in role/company
- Briefly state experience and core expertise
- Connect background to requirements

### Body (2-3 paragraphs)
- Highlight 3-5 key achievements with metrics
- Map experience to job requirements
- Show collaboration and industry knowledge

### Closing
- Reinforce enthusiasm
- Summarize unique value
- Call to action
- Thank reader

## Tips

- Keep to one page (600-800 words)
- Use active voice
- Mirror job description language
- Match template to resume template
- Customize for each company

## Integration

Complete workflow:
1. `managing-resume-versions` - manage versions
2. `extracting-resumes` - convert to YAML
3. `optimizing-resumes` - tailor for role
4. `formatting-resumes` - generate resume PDF
5. `generating-cover-letters` - generate cover letter (this)
6. `reviewing-resumes` - review both
