---
name: extracting-resumes
description: Extracts PDF/DOCX resumes to structured YAML format. Use when the user has a resume file to convert, mentions importing an existing resume, or starts a resume workflow with a document.
license: MIT
compatibility: opencode
metadata:
  audience: job-seekers
  workflow: resume-management
---

# Resume Extractor

Extract resume content from PDF or DOCX files and convert to structured YAML.

## Workflow

### 1. Extract Text from Resume

**PDF:**
```bash
python resume-extractor/scripts/extract_pdf.py resume.pdf --output extracted_text.txt
```

**DOCX:**
```bash
python resume-extractor/scripts/extract_docx.py resume.docx --output extracted_text.txt
```

### 2. Parse to YAML

Using the extracted text, create YAML following `resume-extractor/references/resume_schema.yaml`:

**Required:** `contact`
**Recommended:** `summary`, `experience`, `skills`, `education`
**Optional:** `certifications`, `projects`, `publications`, `awards`, `languages`, `volunteer`

### 3. Validate

- Verify all sections captured
- Check contact info complete
- Ensure dates consistent (e.g., "Jan 2020 - Dec 2022")
- Confirm bullets start with action verbs

## Tips

- Multi-column PDFs may need reordering
- Bold/italic formatting is lost during extraction
- Standardize date format to "Month Year"

## Next Steps

After extracting:
1. Edit/refine YAML manually
2. Use `optimizing-resumes` to improve content
3. Use `formatting-resumes` to generate PDF
