---
name: creating-resume-templates
description: Creates custom Typst resume templates tailored to specific content and page requirements. Use when the content doesn't fit built-in templates, the user needs custom styling, or content overflows the target page count.
license: MIT
compatibility: opencode
metadata:
  audience: job-seekers
  workflow: resume-management
---

# Resume Template Maker

Create custom Typst resume templates that fit specific content.

## When to Use

- Content doesn't fit target page count
- Content overflows onto partial second page
- User has significantly more/less experience
- Spacing feels too tight or loose
- Industry-specific styling needed

## Content Fitting (Do First)

### Quick Tuning

| Too Much Content | Parameter | Too Little |
|-----------------|-----------|------------|
| Reduce to 0.5in | Margins | Increase to 0.75in |
| Reduce to 9pt | Body font | Increase to 10.5pt |
| Reduce to 0.5em | Line height | Increase to 0.7em |
| Reduce to 6pt | Section gap | Increase to 12pt |

### Content Reduction (When Still Too Long)

1. Reduce bullets per role (4-5)
2. Combine/remove older positions
3. Condense skills
4. Shorten summary
5. Remove optional sections

### Whitespace Addition (When Too Short)

1. Add summary section
2. Expand skills
3. Add Projects section
4. Include certifications/awards

## Workflow

1. Assess content volume and target pages
2. Choose starting template (executive, tech-modern, modern-dense, compact, minimal)
3. Compile with actual content
4. Evaluate fit
5. Create custom template
6. Iterate using `reviewing-resumes`

## Built-in Templates

| Template | Best For | Style |
|----------|----------|-------|
| executive | Professional roles | Navy accents |
| tech-modern | Tech/creative | Lavender palette |
| modern-dense | Extensive experience | Maximum density |
| compact | 1-page strict | Minimal spacing |
| minimal | Clean/understated | Monochromatic |

## Output Checklist

- [ ] Content fits target pages
- [ ] No orphan lines
- [ ] Compiles without errors
- [ ] Handles all YAML sections
- [ ] Reviewer passes all checks
