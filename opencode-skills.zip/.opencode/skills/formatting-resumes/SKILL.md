---
name: formatting-resumes
description: Converts resume YAML to professionally formatted PDF using Typst templates. Use when the user wants to generate a PDF, compile their resume, compare template layouts, or create print-ready documents.
license: MIT
compatibility: opencode
metadata:
  audience: job-seekers
  workflow: resume-management
---

# Resume Formatter

## Overview

Transform resume YAML files into professionally formatted PDF documents using Typst templates. Choose from 5 templates optimized for different use cases.

## Quick Start

```bash
# Step 1: Convert YAML to Typst
python resume-formatter/scripts/yaml_to_typst.py resume.yaml executive --output resume.typ

# Step 2: Compile to PDF
python resume-formatter/scripts/compile_typst.py resume.typ

# Result: resume.pdf
```

## Available Templates

### Template Selection Guide

| Need? | Template |
|-------|----------|
| Professional default | Executive |
| Modern/creative | Tech Modern |
| Maximum density | Modern Dense or Compact |
| Clean/understated | Minimal |

**Executive** (default)
- Best for: Most professional roles, senior positions
- Style: Clean hierarchy, navy/blue accents, Inter font

**Tech Modern**
- Best for: Modern tech/creative roles
- Style: Deep lavender palette, pill-style skills

**Modern Dense**
- Best for: Extensive experience requiring optimal space usage
- Style: Categorized inline skills, 20-25 bullets

**Compact**
- Best for: Extensive experience, dense content

**Minimal**
- Best for: Clean, understated presentation, monochromatic

## Workflow

### Convert YAML to Typst

```bash
python resume-formatter/scripts/yaml_to_typst.py <yaml_file> <template> --output <output.typ>
```

Templates: `executive`, `tech-modern`, `modern-dense`, `compact`, `minimal`

Options:
- `--output` / `-o`: Output file path
- `--skip-validation`: Skip schema validation for legacy YAML

### Compile Typst to PDF

```bash
python resume-formatter/scripts/compile_typst.py <typ_file> [--output <output.pdf>]
```

### Prerequisites

**Typst Installation:**

```bash
# macOS
brew install typst

# Linux
cargo install typst-cli

# Windows
winget install --id Typst.Typst
```

Verify: `typst --version`

## Tips

1. Optimize YAML using `optimizing-resumes` skill first
2. Keep resume to 1-2 pages
3. Always review PDF before submitting
4. Test text extraction (copy-paste from PDF)

## Complete Example

```bash
# Convert to Typst with executive template
python resume-formatter/scripts/yaml_to_typst.py resume.yaml executive --output resume_executive.typ

# Compile to PDF
python resume-formatter/scripts/compile_typst.py resume_executive.typ --output final_resume.pdf
```

## Integration

Complete resume workflow:
1. **Extract:** `extracting-resumes` - PDF/DOCX to YAML
2. **Optimize:** `optimizing-resumes` - Improve content
3. **Format:** `formatting-resumes` - Generate PDF (this skill)
