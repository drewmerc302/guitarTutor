---
name: managing-resume-versions
description: Manages resume projects and versions. Use first when the user starts resume work to initialize projects, import files, create versions before changes, or switch between resume variants for different roles.
license: MIT
compatibility: opencode
metadata:
  audience: job-seekers
  workflow: resume-management
---

# Resume State Manager

Manage resume versions across multiple projects/target roles.

## Quick Start

### Initialize Project
```bash
python resume-state/scripts/init_project.py ml_engineer
```

### Import Existing Resume
```bash
python resume-state/scripts/import_resume.py resume.pdf --project ml_engineer
```

### Create New Version
```bash
python resume-state/scripts/create_version.py --tag google --notes "Tailored for Google SWE"
```

### List Versions
```bash
python resume-state/scripts/list_versions.py
```

### Switch Active Version
```bash
python resume-state/scripts/switch_version.py v1
```

### Get Active YAML Path
```bash
python resume-state/scripts/get_active.py
```

## Storage Structure

```
.resume_versions/
├── config.json
└── projects/
    └── ml_engineer/
        ├── project.json
        ├── sources/
        ├── versions/
        │   ├── v1/resume.yaml
        │   └── v2_google/resume.yaml
        └── jobs/
```

## Commands

| Command | Description |
|---------|-------------|
| `init_project.py <name>` | Create new project |
| `import_resume.py <file>` | Import PDF/DOCX |
| `create_version.py` | Branch new version |
| `list_versions.py` | Show version history |
| `switch_version.py <id>` | Change active version |
| `get_active.py` | Print active YAML path |
| `diff_versions.py <a> <b>` | Compare YAML |
