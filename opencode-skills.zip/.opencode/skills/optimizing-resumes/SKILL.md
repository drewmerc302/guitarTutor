---
name: optimizing-resumes
description: Optimizes resume content for target roles with ATS optimization, impact quantification, and keyword alignment. Use when the user wants to tailor for a job posting, improve bullets, add metrics, or strengthen action verbs.
license: MIT
compatibility: opencode
metadata:
  audience: job-seekers
  workflow: resume-management
---

# Resume Optimizer

Improve resume content through ATS optimization, impact quantification, and keyword alignment.

## Quick Start

### For Job-Specific Tailoring

1. Fetch job description: `python resume-optimizer/scripts/fetch_job_posting.py "<url>" --output job.txt`
2. Analyze requirements, identify keyword gaps
3. Tailor content to match job requirements
4. Apply ATS optimization

### For General Optimization

1. Review content quality
2. Add metrics and quantifiable results
3. Strengthen action verbs
4. Apply ATS optimization

## ATS Checklist

- [ ] Standard headers (Experience, Education, Skills)
- [ ] Include exact phrases from job description
- [ ] List acronyms AND spelled-out versions
- [ ] Simple, clean structure (no tables, columns)
- [ ] Standard fonts
- [ ] Contact info at top
- [ ] Consistent date formatting
- [ ] Reverse chronological experience
- [ ] Action verbs starting each bullet

## Impact Formula

```
[Action Verb] + [What You Did] + [Measurable Result]
```

### Metric Categories

- **Time/Speed:** Reduced X from Y to Z
- **Cost/Revenue:** Saved $X, generated $X revenue
- **Scale/Volume:** Processed X items, served X users
- **Quality/Accuracy:** Improved accuracy from X% to Y%
- **Efficiency:** Automated X% of process

## Action Verb Strengthening

Replace weak verbs:
- "Helped" → "Enabled", "Facilitated"
- "Worked on" → "Built", "Implemented"
- "Responsible for" → "Owned", "Managed", "Led"

## Output

Provide optimized YAML with:
- Updated professional summary
- Reordered/rewritten experience bullets
- Enhanced skills section
- Added metrics and impact
- Summary of changes made
