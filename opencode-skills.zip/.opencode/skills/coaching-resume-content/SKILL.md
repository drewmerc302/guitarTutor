---
name: coaching-resume-content
description: Discovers, expands, and articulates resume content through adaptive conversation. Use when the user says they don't know what to put, needs help thinking of achievements, has thin content, or wants to expand weak bullets.
license: MIT
compatibility: opencode
metadata:
  audience: job-seekers
  workflow: resume-management
---

# Resume Coach

Discover hidden achievements through adaptive conversation.

## When to Activate

- User says "I don't know what to put"
- Resume content is thin
- User adding new experience
- Comparing to job posting reveals gaps

## Approach

### 1. Assess First

Check current resume YAML and any job posting context.

### 2. Ask One Question at a Time

**Impact questions:**
- "What's the biggest problem you solved?"
- "What would have happened if you weren't there?"
- "What are you most proud of?"

**Scope questions:**
- "How many users/customers did this affect?"
- "What was the budget/team size?"

**Metrics questions:**
- "Do you have any numbers?"
- "How much faster/better than before?"

### 3. Expand Weak Bullets

Use STAR:
- **Situation:** What was the context?
- **Task:** What were you asked to do?
- **Action:** What did you actually do?
- **Result:** What happened? Include numbers.

### 4. Find Missing Metrics

When users say "I don't have numbers":
- Estimate magnitude: hundreds, thousands, millions?
- Compare: How much faster/better than before?
- Use alternatives: time saved, error reduction

## Output

After coaching, provide:
1. Updated resume YAML with new/expanded bullets
2. Summary of discoveries made
3. Remaining gaps to address
